# game-work


## Introduction

For this exercise, you'll be building DUCK HUNT, using HTML, CSS, and JavaScript.


#### Starter Code

- You have been provided with starter code, so you will ONLY need to work in the ducky.js file and ducky.css (only making directed changes in css file).
- To make this activity more managable, it is broken into 3 parts. Additionally, you have been given guidance on each step.

Please find some screenshots of what you'll be creating. Feel free to get creative with how you style your interface.

![Screen-shot](./images/duck-hunt-part-1.png) - Part 1
![Screen-shot](./images/duck-hunt-part-2.png) - Part 2